java -jar cheeselobby-0.2-SNAPSHOT-jar-with-dependencies.jar
